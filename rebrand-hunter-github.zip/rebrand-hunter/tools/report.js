import fs from 'fs';
import path from 'path';

const outDir = path.join(process.cwd(), 'out');
const summaryPath = path.join(outDir, 'summary.csv');

if (!fs.existsSync(summaryPath)) {
  console.error('No summary.csv found in out/. Did the audit run?');
  process.exit(1);
}

const csv = fs.readFileSync(summaryPath, 'utf8').trim().split(/\r?\n/);
const headers = csv[0].split(',');
const rows = csv.slice(1).map(line => {
  // naive CSV split; good enough for our fields
  const parts = line.split(',');
  const obj = {};
  headers.forEach((h, i) => obj[h] = parts[i] || '');
  return obj;
});

const htmlRows = rows.map(r => {
  const domain = r.domain || (new URL(r.url)).hostname;
  const mobile = `./${domain}/mobile.png`;
  const desktop = `./${domain}/desktop.png`;
  const score = Number(r.rebrand_score || r.rebrand || 0);
  const badge = score >= 70 ? '🔥 Hot' : score >= 55 ? '⚠️ Warm' : '🧊 Cold';
  return `
  <tr>
    <td><a href="${r.url}" target="_blank" rel="noopener">${domain}</a></td>
    <td>${r.name || ''}</td>
    <td>${r.city || ''}</td>
    <td><b>${score}</b> <small>${badge}</small></td>
    <td>${r.lcp_s || ''}</td>
    <td>${r.tel_above_fold}</td>
    <td>${r.whatsapp}</td>
    <td>${r.sticky_cta}</td>
    <td><a href="${mobile}" target="_blank">mobile</a> · <a href="${desktop}" target="_blank">desktop</a></td>
  </tr>`;
}).join('\n');

const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rebrand Hunter Report</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial,sans-serif; margin:40px; line-height:1.4}
table{border-collapse:collapse; width:100%}
th,td{border:1px solid #ddd; padding:8px; font-size:14px}
th{background:#f6f6f6; position:sticky; top:0}
tr:nth-child(even){background:#fafafa}
.badge{padding:2px 6px; border-radius:6px; font-size:12px}
</style>
</head><body>
<h1>Rebrand Hunter Report</h1>
<p>Generated at ${new Date().toISOString()}</p>
<table>
<thead>
<tr>
<th>Domain</th><th>Name</th><th>City</th><th>Rebrand Score</th><th>LCP (s)</th><th>Call above fold</th><th>WhatsApp</th><th>Sticky CTA</th><th>Screens</th>
</tr>
</thead>
<tbody>
${htmlRows}
</tbody>
</table>
<p><small>Open each domain folder for JSON details.</small></p>
</body></html>`;

fs.writeFileSync(path.join(outDir, 'index.html'), html, 'utf8');
console.log('HTML report written to out/index.html');
